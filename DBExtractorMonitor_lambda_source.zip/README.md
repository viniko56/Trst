# DBExtractorMonitor on AWS Lambda (zip, Python 3.12)

Event: {"branch": "dev", "workflow": "commitment2care_com_dev.yml"}  -> triggers the GitHub workflow.

## Build
pip install -r requirements.txt --target ./package
cp -r lambda_function.py src app.conf git.conf package/
cd package && zip -r ../monitor.zip .
Upload monitor.zip; handler = lambda_function.lambda_handler; timeout 30 s.

## Token
git.conf ships with an empty git_fine_grain_token. Set env var GIT_FINE_GRAIN_TOKEN, or a Secrets Manager
secret (SECRET_NAME) with JSON key git_fine_grain_token. Rotate the token that is committed in the repo.
