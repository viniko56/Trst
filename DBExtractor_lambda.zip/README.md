# DBExtractor on AWS Lambda (container image)

Event: {"domain": "commitment2care.com", "env": "dev"}

## Build and deploy
aws ecr create-repository --repository-name dbextractor
docker build --platform linux/amd64 -t dbextractor .
aws ecr get-login-password | docker login --username AWS --password-stdin <acct>.dkr.ecr.<region>.amazonaws.com
docker tag dbextractor:latest <acct>.dkr.ecr.<region>.amazonaws.com/dbextractor:latest
docker push <acct>.dkr.ecr.<region>.amazonaws.com/dbextractor:latest
Then: Lambda > Create function > Container image. Timeout 5-15 min, memory 512 MB+.

## Secrets
Create one Secrets Manager secret (JSON) with keys: RDS_ENDPOINT, RDS_USER, RDS_PASSWD, FTP_HOST,
FTP_USER, FTP_PASSWORD, GPG_KEY (recipient), GPG_PUBLIC_KEY (armored public key).
Set env var SECRET_NAME on the function and grant secretsmanager:GetSecretValue to its role.

## Network
Attach the function to the VPC/subnets that can reach the RDS SQL Server (security group allows 1433).
Outbound SFTP to MOVEit needs a NAT gateway (or other route to the internet / partner).

## Test
Console > Test tab > event {"domain": "commitment2care.com", "env": "dev"}; logs in CloudWatch.
Schedule it with an EventBridge rule using the same JSON as the input.
