"""AWS Lambda entry point for DBExtractor.

Event:  {"domain": "commitment2care.com", "env": "dev"}   (env: dev | qa | prod)
Secrets (env vars, or one Secrets Manager secret named in SECRET_NAME holding a JSON object):
  RDS_ENDPOINT, RDS_USER, RDS_PASSWD, FTP_HOST, FTP_USER, FTP_PASSWORD, GPG_KEY, GPG_PUBLIC_KEY
"""
import configparser
import importlib
import json
import logging
import os
import shutil
from types import SimpleNamespace

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WORK_DIR = "/tmp/DBExtractor_work"  # Lambda's only writable path
SECRET_KEYS = ("RDS_ENDPOINT", "RDS_USER", "RDS_PASSWD", "FTP_HOST", "FTP_USER",
               "FTP_PASSWORD", "GPG_KEY", "GPG_PUBLIC_KEY")

logging.getLogger().setLevel(logging.INFO)
logger = logging.getLogger("DBExtractor.lambda")

_secrets_loaded = False


def _load_secrets():
    """Copy values from Secrets Manager into os.environ (the extractor code reads os.getenv)."""
    global _secrets_loaded
    name = os.getenv("SECRET_NAME")
    if _secrets_loaded or not name:
        return
    import boto3
    secret = json.loads(boto3.client("secretsmanager").get_secret_value(SecretId=name)["SecretString"])
    for key in SECRET_KEYS:
        if key in secret:
            os.environ[key] = str(secret[key])
    _secrets_loaded = True


def lambda_handler(event, context):
    event = event or {}
    domain = event.get("domain")
    env = event.get("env") or os.getenv("ENV")

    config = configparser.ConfigParser()
    config.read(os.path.join(BASE_DIR, "DBExtractor", "DBExtractor.conf"))

    # Only domains defined in the config can be loaded (no arbitrary module imports).
    if domain not in config.sections() or env not in ("dev", "qa", "prod"):
        msg = "'domain' (a section of DBExtractor.conf) and 'env' (dev/qa/prod) are required"
        logger.error(msg)
        return {"statusCode": 400, "body": json.dumps({"message": msg})}

    try:
        _load_secrets()
        config.set(domain, "data_directory_path", WORK_DIR)
        config.set(domain, "log_file_path", WORK_DIR)

        module = importlib.import_module("DBExtractor.targets." + domain.replace(".", "_"))
        extractor_class = getattr(module, config.get(domain, "class_name"))
        extractor_class(SimpleNamespace(domain=domain, env=env), config).execute()

        logger.info("Execution Completed")
        return {"statusCode": 200, "body": json.dumps({"message": f"{domain} ({env}) extract uploaded"})}
    except Exception:
        logger.exception("Extraction failed")
        raise  # let Lambda mark the invocation failed so alarms/retries fire
    finally:
        shutil.rmtree(WORK_DIR, ignore_errors=True)  # don't leave plaintext CSV in a warm container
