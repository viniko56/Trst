import os

import paramiko

from .ftp_base import FtpBase


class Commitment2care(FtpBase):
    def __init__(self, args, config):
        super().__init__(args, config)
        self._transport = None

    def connect(self):
        # NOTE: like the original pysftp code (hostkeys=None), the host key is not verified.
        self._transport = paramiko.Transport((os.getenv("FTP_HOST"), int(os.getenv("FTP_PORT", "22"))))
        self._transport.connect(username=os.getenv("FTP_USER"), password=os.getenv("FTP_PASSWORD"))
        self.connection = paramiko.SFTPClient.from_transport(self._transport)

    def disconnect(self):
        super().disconnect()
        if self._transport:
            try:
                self._transport.close()
            finally:
                self._transport = None
