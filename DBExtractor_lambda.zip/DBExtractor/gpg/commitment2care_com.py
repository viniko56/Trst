import os
import subprocess

from .gpg_base import GpgBase


class Commitment2care(GpgBase):
    def __init__(self, args, config):
        super().__init__(args, config)

    def encrypt(self, file_path):
        # Lambda's filesystem is read-only except /tmp, so keep the keyring there.
        home = os.getenv("GNUPGHOME", "/tmp/gnupg")
        os.makedirs(home, exist_ok=True)
        os.chmod(home, 0o700)
        env = dict(os.environ, GNUPGHOME=home)

        public_key = os.getenv("GPG_PUBLIC_KEY")
        if public_key:
            imp = subprocess.run(["gpg", "--batch", "--import"], input=public_key,
                                 check=False, capture_output=True, text=True, env=env)
            if imp.returncode != 0:
                raise RuntimeError(f"gpg key import failed: {imp.stderr}")

        result = subprocess.run(["gpg", "--batch", "--yes",
                                 "--recipient", os.getenv("GPG_KEY"),
                                 "--encrypt", "--trust-model", "always",
                                 file_path],
                                check=False, capture_output=True, text=True, env=env)
        if result.returncode != 0:
            raise RuntimeError(f"gpg encrypt failed: {result.stderr}")
        self.logger.info("Encrypted %s", file_path)
